#ifndef ERROR_HANDLING_H
#define ERROR_HANDLING_H

bool error_word(char word[]);
bool error_number(char number[]);
bool error_zip(char zip[]);
bool error_street_name(char street_name[]);
bool error_mail(char e_mail[]);

#endif