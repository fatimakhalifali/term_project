#ifndef STRUCTS_ENUM_H
#define STRUCTS_ENUM_H

typedef enum length {
	MAX_CONTACT = 20,
	WORD_LEN = 41,
	ZIP_LEN = 11,
	CODE_LEN = 5,
	NUMBER_LEN = 16,
	MAIL_LEN = 31,
} Length;

typedef struct name {
	char first[WORD_LEN];
	char last[WORD_LEN];
} Name;

typedef struct number {
	char code[CODE_LEN];
	char number[NUMBER_LEN];
} Number;

typedef struct address {
	char line[WORD_LEN];
	char city[WORD_LEN];
	char country[WORD_LEN];
	char zip[ZIP_LEN];
} Address;

typedef struct contact {
	Name name;
	Number phone;
	Address address;
	char e_mail[MAIL_LEN];
	char job[WORD_LEN];
	char relation[WORD_LEN];
} Contact;

void create(Contact*, FILE*);
void print(Contact*, FILE*);
void search(); //by filtering //by all struct attributes
void search_by_name(Contact*, FILE*);
void search_by_phone(Contact*, FILE*);
void search_by_address(Contact*, FILE*);
void search_by_email(Contact*, FILE*);
void search_by_job(Contact*, FILE*);
void search_by_relation(Contact*, FILE*);
void filter();
void edit(Contact*, FILE*);
void edit_first_name(Contact*, FILE*);
void edit_last_name(Contact*, FILE*);
void edit_code(Contact*, FILE*);
void edit_number(Contact*, FILE*);
void edit_line(Contact*, FILE*);
void edit_city(Contact*, FILE*);
void edit_country(Contact*, FILE*);
void edit_zip(Contact*, FILE*);
void edit_email(Contact*, FILE*);
void edit_job(Contact*, FILE*);
void edit_relation(Contact*, FILE*);
void delete(Contact*, FILE*);
void sort(Contact*, FILE*);
int compare_first_name(const void*, const void*);
int compare_last_name(const void*, const void*);
int compare_code(const void*, const void*);
int compare_number(const void*, const void*);
int compare_line(const void*, const void*);
int compare_city(const void*, const void*);
int compare_country(const void*, const void*);
int compare_zip(const void*, const void*);
int compare_email(const void*, const void*);
int compare_job(const void*, const void*);
int compare_relation(const void*, const void*);
void sort_by_address(Contact*, FILE*);
void sort_by_email(Contact*, FILE*);
void sort_by_job(Contact*, FILE*);
void sort_by_relation(Contact*, FILE*);

#endif