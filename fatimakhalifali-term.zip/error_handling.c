#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include "error_handling.h"

bool error_word(char word[]) {
	for (int i = 0; i < strlen(word); i++)
	{
		if (!(isalpha(word[i])) && word[i] != ' ') {
			return false;
		}
		else if (isalpha(word[i]) || word[i] == ' ') {
			continue;
		}
	}
	return true;
}

bool error_number(char number[]) {
	for (int i = 0; i < strlen(number); i++)
	{
		if (!(isdigit(number[i]))) {
			return false;
		}
		else if (isdigit(number[i])) {
			continue;
		}
	}
	return true;
}

bool error_zip(char zip[]) {
	for (int i = 0; i < strlen(zip); i++)
	{
		if (!(isalnum(zip[i]))) {
			return false;
		}
		else if (isalnum(zip[i])) {
			continue;
		}
	}
	return true;
}

bool error_street_name(char street_name[]) {
	for (int i = 0; i < strlen(street_name); i++)
	{
		if (isalnum(street_name[i]) == false && street_name[i] != ' ') {
			return false;
		}
		else {
			continue;
		}
	}
	return true;
}

bool error_mail(char e_mail[]) {
	int prefix_count = 0;

	for (int i = 0; i < strlen(e_mail); i++)
	{
		if (e_mail[i] == '@') {
			break;
		}
		prefix_count++;
	}

	for (int i = 0; i < prefix_count; i++)
	{
		if (prefix_count < 2) {
			printf("* E-mail prefix must contain at least 2 characters.\n");
			return false;
		}
		else if (isalnum(e_mail[i]) == false && e_mail[i] != '.' && e_mail[i] != '_' && e_mail[i] != '-' && e_mail[i] != ',') {
			printf("* E-mail prefix must contain only letters, digits, dot, underscore, dash and period.\n");
			return false;
		}
		else if (isalnum(e_mail[0]) == false) {
			printf("* E-mail prefix must start only with a letter or a digit.\n");
			return false;
		}
		else if (isalnum(e_mail[strlen(e_mail) - 1]) == false) {
			printf("* E-mail prefix must finish only with a letter or a digit.\n");
			return false;
		}
		else if (isalnum(e_mail[i]) == false && isalnum(e_mail[i + 1]) == false) {
			printf("* E-mail prefix must not have 2 dots, underscores, dashes and periods next to each other.\n");
			return false;
		}
	}

	int domain_count = 0;

	for (int i = prefix_count + 1; e_mail[i] != '\0'; i++)
	{
		domain_count++;
	}

	for (int i = 0; i < 1; i++)
	{
		if (domain_count != 7 && domain_count != 9) {
			printf("* E-mail structure (prefix@domain). Domain must be either [mail.ru] or [gmail.com].\n");
			return false;
		}
		else if (domain_count == 7) {
			if (!(strstr(e_mail, "mail.ru"))) {
				printf("* E-mail structure (prefix@domain). Domain must be either [mail.ru] or [gmail.com].\n");
				return false;
			}
		}
		else if (domain_count == 9) {
			if (!(strstr(e_mail, "gmail.com"))) {
				printf("* E-mail structure (prefix@domain). Domain must be either [mail.ru] or [gmail.com].\n");
				return false;
			}
		}
	}
	return true;
}