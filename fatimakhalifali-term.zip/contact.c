#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include "readline.h"
#include "error_handling.h"
#include "structs_enum.h"
#pragma warning(disable : 4996)

Contact* v;
FILE* outfile;

int main() {
	outfile = fopen("outfile.dat", "rb+");
	v = (Contact*)malloc(MAX_CONTACT * sizeof(Contact));
	printf("%d\n", sizeof(Contact));

	char operation_num;

	for (;;) {
		printf("************************\n");
		printf("| 1 | + Create\n");
		printf("| 2 | + List All\n");
		printf("| 3 | + Search\n");
		printf("| 4 | - Filter\n");
		printf("| 5 | +-Edit\n");
		printf("| 6 | - Delete\n");
		printf("| 7 | + Sort\n");
		printf("| 8 | + Quit\n");
		printf("************************\n\n");

		printf("Enter operation number: ");
		scanf("%c", &operation_num);
		while (getchar() != '\n')
			;
		switch (operation_num) {
		case '1':
			create(v, outfile);
			break;
		case '2':
			print(v, outfile);
			break;
		case '3':
			search();
			break;
		case '4':
			break;
		case '5':
			edit(v, outfile);
			break;
		case '6':
			delete(v, outfile);
			break;
		case '7':
			sort(v, outfile);
			break;
		case '8':
			fclose(outfile);
			free(v);
			return 0;
		default:
			printf("Invalid input. See the menu and enter again.\n");
		}
		printf("\n");
	}
}

void create(Contact* pc, FILE* outfile) {

	printf("*NAME*\n");
	printf("Enter contact's first name: ");
	readline(pc->name.first, WORD_LEN);
	while (error_word(pc->name.first) == false) {
		printf("* First name must contain ONLY LETTERS.\n\n");
		printf("Enter again: ");
		readline(pc->name.first, WORD_LEN);
	}

	printf("Enter contact's last name: ");
	readline(pc->name.last, WORD_LEN);
	while (error_word(pc->name.last) == false) {
		printf("* Last name must contain ONLY LETTERS.\n\n");
		printf("Enter again: ");
		readline(pc->name.last, WORD_LEN);
	}
	printf("\n");

	printf("*PHONE NUMBER*\n");
	printf("Enter the cellular code of the contact's country: ");
	readline(pc->phone.code, CODE_LEN);
	while (error_number(pc->phone.code) == false) {
		printf("* Cellular code must contain ONLY DIGITS.\n\n");
		printf("Enter again: ");
		readline(pc->phone.code, CODE_LEN);
	}

	printf("Enter contact's phone number: ");
	readline(pc->phone.number, NUMBER_LEN);
	while (error_number(pc->phone.number) == false || !(strlen(pc->phone.number) >= 7 && strlen(pc->phone.number) <= 15)) {
		printf("* Phone number must contain ONLY DIGITS.\n");
		printf("* Phone number must be between 7 and 15 digits.\n\n");
		printf("Enter again: ");
		readline(pc->phone.number, NUMBER_LEN);
	}

	printf("\n");

	printf("*ADDRESS*\n");
	printf("Enter contact's street line: ");
	readline(pc->address.line, WORD_LEN);
	while (error_street_name(pc->address.line) == false) {
		printf("* Street line must contain ONLY LETTERS and DIGITS.\n\n");
		printf("Enter again: ");
		readline(pc->address.line, WORD_LEN);
	}
	printf("Enter contact's city: ");
	readline(pc->address.city, WORD_LEN);
	while (error_word(pc->address.city) == false) {
		printf("* City name must contain ONLY LETTERS.\n\n");
		printf("Enter again: ");
		readline(pc->address.city, WORD_LEN);
	}
	printf("Enter contact's country: ");
	readline(pc->address.country, WORD_LEN);
	while (error_word(pc->address.country) == false) {
		printf("* Country name must contain ONLY LETTERS.\n\n");
		printf("Enter again: ");
		readline(pc->address.country, WORD_LEN);
	}
	printf("Enter contact's ZIP: ");
	readline(pc->address.zip, ZIP_LEN);
	while (error_zip(pc->address.zip) == false) {
		printf("* ZIP must contain ONLY LETTERS and DIGITS.\n\n");
		printf("Enter again: ");
		readline(pc->address.zip, ZIP_LEN);
	}
	printf("\n");

	printf("Enter contact's e-mail (gmail.com/mail.ru): ");
	readline(pc->e_mail, MAIL_LEN);
	while (error_mail(pc->e_mail) == false) {
		printf("\nEnter again: ");
		readline(pc->e_mail, MAIL_LEN);
	}

	printf("Enter contact's occupation: ");
	readline(pc->job, WORD_LEN);
	while (error_word(pc->job) == false) {
		printf("* Occupation must contain ONLY LETTERS.\n\n");
		printf("Enter again: ");
		readline(pc->job, WORD_LEN);
	}

	printf("Enter relationship to the contact: ");
	readline(pc->relation, WORD_LEN);
	while (error_word(pc->relation) == false) {
		printf("* Relationship must contain ONLY LETTERS.\n\n");
		printf("Enter again: ");
		readline(pc->relation, WORD_LEN);
	}

	fseek(outfile, 0, SEEK_END);
	fwrite(pc, sizeof(Contact), 1, outfile);
}

void print(Contact* pc, FILE* outfile) {
	fseek(outfile, 0, SEEK_SET);
	int count = 0;

	while (fread(&pc->name, sizeof(Contact), 1, outfile)) {
		printf("NAME        : %s %s\n", pc->name.first, pc->name.last);
		printf("PHONE NUMBER: %s %s\n", pc->phone.code, pc->phone.number);
		printf("ADDRESS     : %s, %s, %s, %s\n", pc->address.line, pc->address.city, pc->address.country, pc->address.zip);
		printf("E_MAIL      : %s\n", pc->e_mail);
		printf("JOB:        : %s\n", pc->job);
		printf("RELATION    : %s\n\n", pc->relation);
		++count;
	}

	printf("\nTOTAL: %d\n", count);
}

void search() {
	fseek(outfile, 0, SEEK_SET);

	char opt;
	printf("\n");
	printf("        SEARCH BY       \n");
	printf("************************\n");
	printf("| 1 | Name\n");
	printf("| 2 | Phone number\n");
	printf("| 3 | Address\n");
	printf("| 4 | E-mail\n");
	printf("| 5 | Job\n");
	printf("| 6 | Relation\n");
	printf("************************\n\n");

	printf("Enter your choice: ");
	scanf("%c", &opt);

	switch (opt) {
	case '1':
		search_by_name(v, outfile);
		break;
	case '2':
		search_by_phone(v, outfile);
		break;
	case '3':
		search_by_address(v, outfile);
		break;
	case '4':
		search_by_email(v, outfile);
		break;
	case '5':
		search_by_job(v, outfile);
		break;
	case '6':
		search_by_relation(v, outfile);
		break;
	default:
		printf("Invalid input.\n");
	}

}

void search_by_name(Contact* pc, FILE* outfile) {
	char search[WORD_LEN];
	printf("Enter first/last name: ");
	readline(search, WORD_LEN);
	while (fread(&pc->name, sizeof(Contact), 1, outfile)) {
		if (strcmp(pc->name.first, search) == 0 || strcmp(pc->name.last, search) == 0) {
			printf("PHONE NUMBER: %s %s\n", pc->phone.code, pc->phone.number);
			printf("ADDRESS     : %s, %s, %s, %s\n", pc->address.line, pc->address.city, pc->address.country, pc->address.zip);
			printf("E_MAIL      : %s\n", pc->e_mail);
			printf("JOB:        : %s\n", pc->job);
			printf("RELATION    : %s\n\n", pc->relation);
		}
	}
}

void search_by_phone(Contact* pc, FILE* outfile) {
	char search[NUMBER_LEN];
	printf("Enter phone code/number: ");
	readline(search, NUMBER_LEN);
	while (fread(&pc->name, sizeof(Contact), 1, outfile)) {
		if (strcmp(pc->phone.code, search) == 0 || strcmp(pc->phone.number, search) == 0) {
			printf("NAME        : %s %s\n", pc->name.first, pc->name.last);
			printf("ADDRESS     : %s, %s, %s, %s\n", pc->address.line, pc->address.city, pc->address.country, pc->address.zip);
			printf("E_MAIL      : %s\n", pc->e_mail);
			printf("JOB:        : %s\n", pc->job);
			printf("RELATION    : %s\n\n", pc->relation);
		}
	}
}

void search_by_address(Contact* pc, FILE* outfile) {
	char search[WORD_LEN];
	printf("Enter address line/city/country/zip: ");
	readline(search, WORD_LEN);
	while (fread(&pc, sizeof(Contact), 1, outfile)) {
		if (strcmp(pc->address.line, search) == 0 || strcmp(pc->address.city, search) == 0 || strcmp(pc->address.country, search) == 0 || strcmp(pc->address.zip, search) == 0) {
			printf("NAME        : %s %s\n", pc->name.first, pc->name.last);
			printf("PHONE NUMBER: %s %s\n", pc->phone.code, pc->phone.number);
			printf("E_MAIL      : %s\n", pc->e_mail);
			printf("JOB:        : %s\n", pc->job);
			printf("RELATION    : %s\n\n", pc->relation);
		}
	}
}

void search_by_email(Contact* pc, FILE* outfile) {
	char search[MAIL_LEN];
	printf("Enter e-mail address: ");
	readline(search, MAIL_LEN);
	while (fread(&pc->name, sizeof(Contact), 1, outfile)) {
		if (strcmp(pc->e_mail, search) == 0) {
			printf("NAME        : %s %s\n", pc->name.first, pc->name.last);
			printf("PHONE NUMBER: %s %s\n", pc->phone.code, pc->phone.number);
			printf("ADDRESS     : %s, %s, %s, %s\n", pc->address.line, pc->address.city, pc->address.country, pc->address.zip);
			printf("JOB:        : %s\n", pc->job);
			printf("RELATION    : %s\n\n", pc->relation);
		}
	}
}

void search_by_job(Contact* pc, FILE* outfile) {
	char search[WORD_LEN];
	printf("Enter occupation: ");
	readline(search, WORD_LEN);
	while (fread(&pc->name, sizeof(Contact), 1, outfile)) {
		if (strcmp(pc->job, search) == 0) {
			printf("NAME        : %s %s\n", pc->name.first, pc->name.last);
			printf("PHONE NUMBER: %s %s\n", pc->phone.code, pc->phone.number);
			printf("ADDRESS     : %s, %s, %s, %s\n", pc->address.line, pc->address.city, pc->address.country, pc->address.zip);
			printf("E_MAIL      : %s\n", pc->e_mail);
			printf("RELATION    : %s\n\n", pc->relation);
		}
	}
}

void search_by_relation(Contact* pc, FILE* outfile) {
	char search[WORD_LEN];
	printf("Enter relation: ");
	readline(search, WORD_LEN);
	while (fread(&pc->name, sizeof(Contact), 1, outfile)) {
		if (strcmp(pc->relation, search) == 0) {
			printf("NAME        : %s %s\n", pc->name.first, pc->name.last);
			printf("PHONE NUMBER: %s %s\n", pc->phone.code, pc->phone.number);
			printf("ADDRESS     : %s, %s, %s, %s\n", pc->address.line, pc->address.city, pc->address.country, pc->address.zip);
			printf("E_MAIL      : %s\n", pc->e_mail);
			printf("JOB:        : %s\n", pc->job);

		}
	}
}

int contact_count;

void edit(Contact* pc, FILE* outfile) {
	fseek(outfile, 0, SEEK_SET);
	char search[MAIL_LEN];
	char opt;
	int count = 0;
	printf("Enter contact's e-mail address: ");
	readline(search, MAIL_LEN);
	contact_count = 0;
	while (fread(&pc->name, sizeof(Contact), 1, outfile)) {
		if (strcmp(pc->e_mail, search) == 0) {
			++count;
			++contact_count;
		}
	}

	if (count == 1) {

		printf("\n         EDIT         \n");
		printf("************************\n");
		printf("| 1 | First Name\n");
		printf("| 2 | Last Name\n");
		printf("| 3 | Code\n");
		printf("| 4 | Number\n");
		printf("| 5 | Line\n");
		printf("| 6 | City\n");
		printf("| 7 | Country\n");
		printf("| 8 | ZIP\n");
		printf("| 9 | E-mail\n");
		printf("| a | Job\n");
		printf("| b | Relation\n");
		printf("************************\n\n");

		printf("Enter your choice: ");
		scanf("%c", &opt);

		switch (opt) {
		case '1':
			fseek(outfile, 0, SEEK_SET);
			edit_first_name(v, outfile);
			break;
		case '2':
			fseek(outfile, 0, SEEK_SET);
			edit_last_name(v, outfile);
			break;
		case '3':
			fseek(outfile, 0, SEEK_SET);
			edit_code(v, outfile);
			break;
		case '4':
			fseek(outfile, 0, SEEK_SET);
			edit_number(v, outfile);
			break;
		case '5':
			fseek(outfile, 0, SEEK_SET);
			edit_line(v, outfile);
			break;
		case '6':
			fseek(outfile, 0, SEEK_SET);
			edit_city(v, outfile);
			break;
		case '7':
			fseek(outfile, 0, SEEK_SET);
			edit_country(v, outfile);
			break;
		case '8':
			fseek(outfile, 0, SEEK_SET);
			edit_zip(v, outfile);
			break;
		case '9':
			fseek(outfile, 0, SEEK_SET);
			edit_email(v, outfile);
			break;
		case 'a':
			fseek(outfile, 0, SEEK_SET);
			edit_job(v, outfile);
			break;
		case 'b':
			fseek(outfile, 0, SEEK_SET);
			edit_relation(v, outfile);
			break;
		default:
			printf("Invalid input.\n");
		}
	}
	else {
		printf("NOT FOUND\n");
	}
}

void edit_first_name(Contact* pc, FILE* outfile) {
	printf("Enter first name: ");
	char new[WORD_LEN];
	fseek(outfile, (contact_count * sizeof(Contact)) - sizeof(Contact), SEEK_SET);
	readline(new, WORD_LEN);
	fwrite(&new, WORD_LEN, 1, outfile);
}

void edit_last_name(Contact* pc, FILE* outfile) {
	printf("Enter last name: ");
	char new[WORD_LEN];
	fseek(outfile, (contact_count * sizeof(Contact)) - sizeof(Contact) + WORD_LEN, SEEK_SET);
	readline(new, WORD_LEN);
	fwrite(&new, WORD_LEN, 1, outfile);
}

void edit_code(Contact* pc, FILE* outfile) {
	printf("Enter cellular code: ");
	char new[CODE_LEN];
	fseek(outfile, (contact_count * sizeof(Contact)) - sizeof(Contact) + WORD_LEN + WORD_LEN, SEEK_SET);
	readline(new, CODE_LEN);
	fwrite(&new, CODE_LEN, 1, outfile);
}

void edit_number(Contact* pc, FILE* outfile) {
	printf("Enter phone number: ");
	char new[NUMBER_LEN];
	fseek(outfile, (contact_count * sizeof(Contact)) - sizeof(Contact) + WORD_LEN + WORD_LEN + CODE_LEN, SEEK_SET);
	readline(new, NUMBER_LEN);
	fwrite(&new, NUMBER_LEN, 1, outfile);
}

void edit_line(Contact* pc, FILE* outfile) {
	printf("Enter line: ");
	char new[WORD_LEN];
	fseek(outfile, (contact_count * sizeof(Contact)) - sizeof(Contact) + WORD_LEN + WORD_LEN + CODE_LEN + NUMBER_LEN, SEEK_SET);
	readline(new, WORD_LEN);
	fwrite(&new, WORD_LEN, 1, outfile);
}

void edit_city(Contact* pc, FILE* outfile) {
	printf("Enter city: ");
	char new[WORD_LEN];
	fseek(outfile, (contact_count * sizeof(Contact)) - sizeof(Contact) + WORD_LEN + WORD_LEN + CODE_LEN + NUMBER_LEN + WORD_LEN, SEEK_SET);
	readline(new, WORD_LEN);
	fwrite(&new, WORD_LEN, 1, outfile);
}

void edit_country(Contact* pc, FILE* outfile) {
	printf("Enter country: ");
	char new[WORD_LEN];
	fseek(outfile, (contact_count * sizeof(Contact)) - sizeof(Contact) + WORD_LEN + WORD_LEN + CODE_LEN + NUMBER_LEN + WORD_LEN + WORD_LEN, SEEK_SET);
	readline(new, WORD_LEN);
	fwrite(&new, WORD_LEN, 1, outfile);
}

void edit_zip(Contact* pc, FILE* outfile) {
	printf("Enter ZIP: ");
	char new[ZIP_LEN];
	fseek(outfile, (contact_count * sizeof(Contact)) - sizeof(Contact) + WORD_LEN + WORD_LEN + CODE_LEN + NUMBER_LEN + WORD_LEN + WORD_LEN + WORD_LEN, SEEK_SET);
	readline(new, ZIP_LEN);
	fwrite(&new, ZIP_LEN, 1, outfile);
}

void edit_email(Contact* pc, FILE* outfile) {
	printf("Enter e-mail: ");
	char new[MAIL_LEN];
	fseek(outfile, (contact_count * sizeof(Contact)) - sizeof(Contact) + WORD_LEN + WORD_LEN + CODE_LEN + NUMBER_LEN + WORD_LEN + WORD_LEN + WORD_LEN + ZIP_LEN, SEEK_SET);
	readline(new, MAIL_LEN);
	fwrite(&new, MAIL_LEN, 1, outfile);
}

void edit_job(Contact* pc, FILE* outfile) {
	printf("Enter job: ");
	char new[WORD_LEN];
	fseek(outfile, (contact_count * sizeof(Contact)) - sizeof(Contact) + WORD_LEN + WORD_LEN + CODE_LEN + NUMBER_LEN + WORD_LEN + WORD_LEN + WORD_LEN + ZIP_LEN + MAIL_LEN, SEEK_SET);
	readline(new, WORD_LEN);
	fwrite(&new, WORD_LEN, 1, outfile);
}

void edit_relation(Contact* pc, FILE* outfile) {
	printf("Enter relation: ");
	char new[WORD_LEN];
	fseek(outfile, (contact_count * sizeof(Contact)) - sizeof(Contact) + WORD_LEN + WORD_LEN + CODE_LEN + NUMBER_LEN + WORD_LEN + WORD_LEN + WORD_LEN + ZIP_LEN + MAIL_LEN + WORD_LEN, SEEK_SET);
	readline(new, WORD_LEN);
	fwrite(&new, WORD_LEN, 1, outfile);
}

void delete(Contact* pc, FILE* outfile) {
	fseek(outfile, 0, SEEK_SET);
	char search[MAIL_LEN];
	printf("Enter contact's e-mail address: ");
	readline(search, MAIL_LEN);
	contact_count = 0;
	while (fread(&pc->name, sizeof(Contact), 1, outfile)) {
		contact_count++;
	}
	fseek(outfile, 0, SEEK_SET);

	while (fread(&pc->name, sizeof(Contact), 1, outfile)) {
		if (strcmp(pc->e_mail, search) != 0) {
			fseek(outfile, -350, SEEK_CUR);
			fwrite(&pc, sizeof(Contact), 1, outfile);
			fseek(outfile, sizeof(Contact), SEEK_CUR);
		}
	}

}

void sort(Contact* pc, FILE* outfile) {
	fseek(outfile, 0, SEEK_SET);

	char opt;
	printf("\n");
	printf("         SORT BY       \n");
	printf("************************\n");
	printf("| 1 | First Name\n");
	printf("| 2 | Last Name\n");
	printf("| 3 | Code\n");
	printf("| 4 | Number\n");
	printf("| 5 | Line\n");
	printf("| 6 | City\n");
	printf("| 7 | Country\n");
	printf("| 8 | ZIP\n");
	printf("| 9 | E-mail\n");
	printf("| a | Job\n");
	printf("| b | Relation\n");
	printf("************************\n\n");

	printf("Enter your choice: ");
	scanf("%c", &opt);

	int i = 0;
	Contact c[MAX_CONTACT];

	switch (opt) {
	case '1':
		while (fread(c + i, sizeof(Contact), 1, outfile)) {
			qsort(c, MAX_CONTACT, sizeof(Contact), compare_first_name);
			i++;
		}
		for (int j = 0; j < i; j++)
		{
			printf("%10s %10s %5s %10s %8s %8s %8s %5s   %10s  %8s  %8s\n", c[j].name.first, c[j].name.last, c[j].phone.code, c[j].phone.number, c[j].address.line, c[j].address.city, c[j].address.country, c[j].address.zip, c[j].e_mail, c[j].job, c[j].relation);
		}
		i = 0;
		break;
	case '2':
		while (fread(c + i, sizeof(Contact), 1, outfile)) {
			qsort(c, MAX_CONTACT, sizeof(Contact), compare_last_name);
			i++;
		}
		for (int j = 0; j < i; j++)
		{
			printf("%10s %10s %5s %10s %8s %8s %8s %5s   %10s  %8s  %8s\n", c[j].name.first, c[j].name.last, c[j].phone.code, c[j].phone.number, c[j].address.line, c[j].address.city, c[j].address.country, c[j].address.zip, c[j].e_mail, c[j].job, c[j].relation);
		}
		i = 0;
		break;
	case '3':
		while (fread(c + i, sizeof(Contact), 1, outfile)) {
			qsort(c, MAX_CONTACT, sizeof(Contact), compare_code);
			i++;
		}
		for (int j = 0; j < i; j++)
		{
			printf("%10s %10s %5s %10s %8s %8s %8s %5s   %10s  %8s  %8s\n", c[j].name.first, c[j].name.last, c[j].phone.code, c[j].phone.number, c[j].address.line, c[j].address.city, c[j].address.country, c[j].address.zip, c[j].e_mail, c[j].job, c[j].relation);
		}
		i = 0;
		break;
	case '4':
		while (fread(c + i, sizeof(Contact), 1, outfile)) {
			qsort(c, MAX_CONTACT, sizeof(Contact), compare_number);
			i++;
		}
		for (int j = 0; j < i; j++)
		{
			printf("%10s %10s %5s %10s %8s %8s %8s %5s   %10s  %8s  %8s\n", c[j].name.first, c[j].name.last, c[j].phone.code, c[j].phone.number, c[j].address.line, c[j].address.city, c[j].address.country, c[j].address.zip, c[j].e_mail, c[j].job, c[j].relation);
		}
		i = 0;
		break;
	case '5':
		while (fread(c + i, sizeof(Contact), 1, outfile)) {
			qsort(c, MAX_CONTACT, sizeof(Contact), compare_line);
			i++;
		}
		for (int j = 0; j < i; j++)
		{
			printf("%10s %10s %5s %10s %8s %8s %8s %5s   %10s  %8s  %8s\n", c[j].name.first, c[j].name.last, c[j].phone.code, c[j].phone.number, c[j].address.line, c[j].address.city, c[j].address.country, c[j].address.zip, c[j].e_mail, c[j].job, c[j].relation);
		}
		i = 0;
		break;
	case '6':
		while (fread(c + i, sizeof(Contact), 1, outfile)) {
			qsort(c, MAX_CONTACT, sizeof(Contact), compare_city);
			i++;
		}
		for (int j = 0; j < i; j++)
		{
			printf("%10s %10s %5s %10s %8s %8s %8s %5s   %10s  %8s  %8s\n", c[j].name.first, c[j].name.last, c[j].phone.code, c[j].phone.number, c[j].address.line, c[j].address.city, c[j].address.country, c[j].address.zip, c[j].e_mail, c[j].job, c[j].relation);
		}
		i = 0;
		break;
	case '7':
		while (fread(c + i, sizeof(Contact), 1, outfile)) {
			qsort(c, MAX_CONTACT, sizeof(Contact), compare_country);
			i++;
		}
		for (int j = 0; j < i; j++)
		{
			printf("%10s %10s %5s %10s %8s %8s %8s %5s   %10s  %8s  %8s\n", c[j].name.first, c[j].name.last, c[j].phone.code, c[j].phone.number, c[j].address.line, c[j].address.city, c[j].address.country, c[j].address.zip, c[j].e_mail, c[j].job, c[j].relation);
		}
		i = 0;
		break;
	case '8':
		while (fread(c + i, sizeof(Contact), 1, outfile)) {
			qsort(c, MAX_CONTACT, sizeof(Contact), compare_zip);
			i++;
		}
		for (int j = 0; j < i; j++)
		{
			printf("%10s %10s %5s %10s %8s %8s %8s %5s   %10s  %8s  %8s\n", c[j].name.first, c[j].name.last, c[j].phone.code, c[j].phone.number, c[j].address.line, c[j].address.city, c[j].address.country, c[j].address.zip, c[j].e_mail, c[j].job, c[j].relation);
		}
		i = 0;
		break;
	case '9':
		while (fread(c + i, sizeof(Contact), 1, outfile)) {
			qsort(c, MAX_CONTACT, sizeof(Contact), compare_email);
			i++;
		}
		for (int j = 0; j < i; j++)
		{
			printf("%10s %10s %5s %10s %8s %8s %8s %5s   %10s  %8s  %8s\n", c[j].name.first, c[j].name.last, c[j].phone.code, c[j].phone.number, c[j].address.line, c[j].address.city, c[j].address.country, c[j].address.zip, c[j].e_mail, c[j].job, c[j].relation);
		}
		i = 0;
		break;
	case 'a':
		while (fread(c + i, sizeof(Contact), 1, outfile)) {
			qsort(c, MAX_CONTACT, sizeof(Contact), compare_job);
			i++;
		}
		for (int j = 0; j < i; j++)
		{
			printf("%10s %10s %5s %10s %8s %8s %8s %5s   %10s  %8s  %8s\n", c[j].name.first, c[j].name.last, c[j].phone.code, c[j].phone.number, c[j].address.line, c[j].address.city, c[j].address.country, c[j].address.zip, c[j].e_mail, c[j].job, c[j].relation);
		}
		i = 0;
		break;
	case 'b':
		while (fread(c + i, sizeof(Contact), 1, outfile)) {
			qsort(c, MAX_CONTACT, sizeof(Contact), compare_relation);
			i++;
		}
		for (int j = 0; j < i; j++)
		{
			printf("%10s %10s %5s %10s %8s %8s %8s %5s   %10s  %8s  %8s\n", c[j].name.first, c[j].name.last, c[j].phone.code, c[j].phone.number, c[j].address.line, c[j].address.city, c[j].address.country, c[j].address.zip, c[j].e_mail, c[j].job, c[j].relation);
		}
		i = 0;
		break;
	default:
		printf("Invalid input.\n");
	}
}

int compare_first_name(const void* left, const void* right) {
	return strcmp((*(Contact*)left).name.first, (*(Contact*)right).name.first);
}

int compare_last_name(const void* left, const void* right) {
	return strcmp((*(Contact*)left).name.last, (*(Contact*)right).name.last);
}

int compare_code(const void* left, const void* right) {
	return strcmp((*(Contact*)left).phone.code, (*(Contact*)right).phone.code);
}

int compare_number(const void* left, const void* right) {
	return strcmp((*(Contact*)left).phone.number, (*(Contact*)right).phone.number);
}

int compare_line(const void* left, const void* right) {
	return strcmp((*(Contact*)left).address.line, (*(Contact*)right).address.line);
}

int compare_city(const void* left, const void* right) {
	return strcmp((*(Contact*)left).address.city, (*(Contact*)right).address.city);
}

int compare_country(const void* left, const void* right) {
	return strcmp((*(Contact*)left).address.country, (*(Contact*)right).address.country);
}

int compare_zip(const void* left, const void* right) {
	return strcmp((*(Contact*)left).address.zip, (*(Contact*)right).address.zip);
}

int compare_email(const void* left, const void* right) {
	return strcmp((*(Contact*)left).e_mail, (*(Contact*)right).e_mail);
}

int compare_job(const void* left, const void* right) {
	return strcmp((*(Contact*)left).job, (*(Contact*)right).job);
}

int compare_relation(const void* left, const void* right) {
	return strcmp((*(Contact*)left).relation, (*(Contact*)right).relation);
}